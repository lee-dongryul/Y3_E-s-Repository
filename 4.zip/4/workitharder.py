from tkinter import *
from playsound import playsound
import os
import sys

win = Tk()
win.title('work it harder')
win.geometry("330x600")
win.maxsize(width=330,height=600)
win.minsize(width=330,height=600)

def reset():
    os.execl(sys.executable, sys.executable, * sys.argv)
    
    

def workit():
    playsound(r"C:\파이썬파윌\1\효과음\WorkIt.mp3")
    win.after(1, btn1.destroy)

def makeit():
    playsound(r"C:\파이썬파윌\1\효과음\MakeIt.mp3")
    win.after(1, btn2.destroy)

def doit():
    playsound(r"C:\파이썬파윌\1\효과음\DoIt.mp3")
    win.after(1, btn3.destroy)
    
def makesus():
    playsound(r"C:\파이썬파윌\1\효과음\Makesus.mp3")
    win.after(1, btn17.destroy)

def harder():
    playsound(r"C:\파이썬파윌\1\효과음\Harder.mp3")
    win.after(1, btn4.destroy)

def Better():
    playsound(r"C:\파이썬파윌\1\효과음\Better.mp3")
    win.after(1, btn5.destroy)

def faster():
    playsound(r"C:\파이썬파윌\1\효과음\Faster.mp3")
    win.after(1, btn6.destroy)

def Stronger():
    playsound(r"C:\파이썬파윌\1\효과음\Stronger.mp3")
    win.after(1, btn7.destroy)

def Morethan():
    playsound(r"C:\파이썬파윌\1\효과음\Morethan.mp3")
    win.after(1, btn8.destroy)

def Hour():
    playsound(r"C:\파이썬파윌\1\효과음\Hour.mp3")
    win.after(1, btn9.destroy)

def Our():
    playsound(r"C:\파이썬파윌\1\효과음\Our.mp3")
    win.after(1, btn10.destroy)

def Never():
    playsound(r"C:\파이썬파윌\1\효과음\Never.mp3")
    win.after(1, btn11.destroy)

def Ever():
    playsound(r"C:\파이썬파윌\1\효과음\Ever.mp3")
    win.after(1, btn12.destroy)

def After():
    playsound(r"C:\파이썬파윌\1\효과음\After.mp3")
    win.after(1, btn13.destroy)

def workis():
    playsound(r"C:\파이썬파윌\1\효과음\WorkIs.mp3")
    win.after(1, btn14.destroy)

def over():
    playsound(r"C:\파이썬파윌\1\효과음\Over.mp3")
    win.after(1, btn15.destroy)

label1 = Label(win, text="made by ehdfbf#4364 add a friend on discord", bg='white' , fg='blue')
label1.pack()

btn16 = Button(win, text="RESTART",command=reset)
btn16.place(x=130,y=23,width=70,height=25)

btn1 = Button(win, text="Work It",command=workit)
btn1.place(x=10,y=50,width=150,height=50)

btn2 = Button(win, text="Make It",command=makeit)
btn2.place(x=170,y=50,width=150,height=50)

btn3 = Button(win, text="Do It",command=doit)
btn3.place(x=10,y=120,width=150,height=50)

btn17 = Button(win, text="Makes us",command=makesus)
btn17.place(x=170,y=120,width=150,height=50)

btn4 = Button(win, text="Harder",command=harder)
btn4.place(x=10,y=190,width=150,height=50)

btn5 = Button(win, text="Better",command=Better)
btn5.place(x=170,y=190,width=150,height=50)

btn6 = Button(win, text="Faster",command=faster)
btn6.place(x=10,y=260,width=150,height=50)

btn7 = Button(win, text="Stronger",command=Stronger)
btn7.place(x=170,y=260,width=150,height=50)

btn8 = Button(win, text="More Than",command=Morethan)
btn8.place(x=10,y=330,width=150,height=50)

btn9 = Button(win, text="Hour",command=Hour)
btn9.place(x=170,y=330,width=150,height=50)

btn10 = Button(win, text="Our",command=Our)
btn10.place(x=10,y=400,width=150,height=50)

btn11 = Button(win, text="Never",command=Never)
btn11.place(x=170,y=400,width=150,height=50)

btn12 = Button(win, text="Ever",command=Ever)
btn12.place(x=10,y=470,width=150,height=50)

btn13 = Button(win, text="After",command=After)
btn13.place(x=170,y=470,width=150,height=50)  

btn14 = Button(win, text="Work Is",command=workis)
btn14.place(x=10,y=540,width=150,height=50)

btn15 = Button(win, text="Over",command=over)
btn15.place(x=170,y=540,width=150,height=50)

print ("C:\파이썬파윌\1\효과음\After.mp3")











win.mainloop()